Rails.application.routes.draw do

  get 'ideas/index'
  get 'ideas/show'
  # SESSSIONS ROUTES
  root 'sessions#new'
  get 'sessions' => 'sessions#new'
  get 'main' => 'sessions#new'
  post 'sessions' => 'sessions#login'
  delete 'sessions' => 'sessions#logout'

  # USERS ROUTES
  post 'users' => 'users#create'
  get 'users/:id' => 'users#show'

  # IDEAS ROUTES
  get 'ideas' => 'ideas#index'
  get 'ideas/:id' => 'ideas#show'
  post 'ideas/:user_id' => 'ideas#create'
  delete 'ideas/:id' => 'ideas#destroy'

  # LIKES ROUTES
  post 'likes/:id/:user_id' => 'likes#create'
  
  get "*path" => redirect("/")
end
