class LikesController < ApplicationController
    before_action :require_correct_user

    def create
        if Like.exists?(idea: Idea.find(params[:id]), user: User.find(params[:user_id]))
            flash[:messages] = ["User cannot like idea more than once"]
            redirect_back(fallback_location: root_path)
        else
            Like.create(idea: Idea.find(params[:id]), user: User.find(params[:user_id]))
            flash[:messages] = ["Idea liked"]
            redirect_to "/ideas"
        end
    end

    def require_correct_user
        if current_user != User.find(params[:user_id])
            flash[:messages] = ["Correct user required"]
            redirect_to "/ideas"
        end
    end

end
