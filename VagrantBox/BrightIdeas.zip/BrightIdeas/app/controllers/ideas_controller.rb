class IdeasController < ApplicationController
  before_action :require_correct_user, only: [:create]

  def index
    @user = current_user
    @ideas = Idea
      .left_joins(:likes)
      .group(:id)
      .order('COUNT(likes.id) DESC')
  end

  def create
    idea = Idea.create(idea_params)
    if idea.errors.any?
      flash[:messages] = idea.errors.full_messages
      redirect_back(fallback_location: root_path)
    else
      flash[:messages] = ["New Idea Added"]
      redirect_back(fallback_location: root_path)
    end
  end

  def show
    @idea = Idea.find(params[:id])
  end

  def destroy
    idea = Idea.find(params[:id])
    if idea.user == current_user
      idea.destroy
      flash[:messages] = ["Idea destroyed"]
      redirect_back(fallback_location: root_path)
    else
      flash[:messages] = ["Cannot delete other users' ideas"]
      redirect_back(fallback_location: root_path)
    end
  end
  
  def idea_params
    params.require(:idea).permit(:content).merge(user: User.find(params[:user_id]))
  end

  def require_correct_user
        if current_user != User.find(params[:user_id])
            flash[:messages] = ["Correct user required"]
            redirect_to "/ideas"
        end
    end
end
