FactoryBot.define do
  factory :like do
    idea { nil }
    user { nil }
  end
end
