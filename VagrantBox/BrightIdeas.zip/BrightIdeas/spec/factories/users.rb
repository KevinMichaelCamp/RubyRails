FactoryBot.define do
  factory :user do
    name { "MyString" }
    username { "MyString" }
    email { "MyString" }
    password { "" }
  end
end
